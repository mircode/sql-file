log.txt id,name,ip,segment,num |
log.json id,name,ip,segment,num json
