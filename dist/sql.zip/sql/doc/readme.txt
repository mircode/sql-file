#
# ����
## �ָ���
create table log.txt (id,name,ip,segment,num) fmt |;
## JSON��ʽ
create table log.json (id,name,ip,segment,num) fmt json;


# ����
update table log.txt (id,name,ip,segment,num) fmt format.class;
desc log.txt;
select * from log.txt;

update table log.txt (id,name,ip,segment,num) fmt format.js;
desc log.txt;
select * from log.txt;

update table log.txt (id,name,ip,segment,num) fmt ~(.*?)|(.*?)|(.*?)|(.*?)|(.*);
desc log.txt more;
select * from log.txt;

# ��ʾ���б�
show tables;

# �ṹ��ѯ
desc log.json;
desc log.txt;

# �򵥲�ѯ
select name,ip from log.txt;
select name,ip from log.json;
select name,ip from log.{txt,json};  
  
# ������ѯ
select * from log.txt  where name='taobao' or name='ctrip';
select * from log.json where name='taobao' or name='ctrip';
select * from log.{txt,json} where name='taobao' or name='ctrip';

# JSON��ѯ
select name,json_path(segment,$.service) from log.txt;
select name,json_path(segment,$.service) from log.json;
select name,json_path(segment,$.service) from log.{json,txt};

# �ۺϲ�ѯ
select name,sum(num) as total,avg(num),max(num),min(num),count(num) from log.txt  group by name;
select name,sum(num) as total,avg(num),max(num),min(num),count(num) from log.json group by name;
select name,sum(num) as total,avg(num),max(num),min(num),count(num) from log.{txt,json} group by name;

# ɾ��
drop table log.txt;
drop table log.json;

# ����ִ�н��
